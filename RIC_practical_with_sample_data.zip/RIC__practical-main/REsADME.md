# RIC__practical
